#!/bin/sh

########################################################################
#
#  Convert an rtf document to HTML format using 'Ted'.
#
#  Usage	rtf2html.sh something.rtf something.html
#
#  This is an example. Refer to http://www.nllgg.nl/Ted/index.html for the
#  'Ted' documentation.
#
########################################################################

case $# in
    1)
	rtf="$1";
	html=`basename "$1" .rtf`.html
	;;
    2)
	rtf="$1";
	html="$2";
	;;
    *)
	echo $0: '$#='$#
	exit 1
	;;
esac

Ted --saveTo "$rtf" "$html"

