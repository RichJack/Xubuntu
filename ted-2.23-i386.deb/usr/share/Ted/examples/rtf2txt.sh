#!/bin/sh

########################################################################
#
#  Convert an rtf document to plain text format using 'Ted'.
#
#  Usage	rtf2txt.sh something.rtf something.txt
#
#  This is an example. Refer to http://www.nllgg.nl/Ted/index.html for the
#  'Ted' documentation.
#
########################################################################

case $# in
    1)
	rtf="$1";
	txt=`basename "$1" .rtf`.txt
	;;
    2)
	rtf="$1";
	txt="$2";
	;;
    *)
	echo $0: '$#='$#
	exit 1
	;;
esac

Ted --saveTo "$rtf" "$txt"

