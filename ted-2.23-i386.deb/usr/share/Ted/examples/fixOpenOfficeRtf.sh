#!/bin/sh

####
####    Some attempts to make OpenOffice rtf more like 
####    Microsoft rtf as documented.
####

IN=sample.rtf
OUT=ss.rtf

sed	-e 's/^{\\headerf/\\titlepg{\\headerf/' \
	-e 's/^{\\headerl/\\facingp{\\headerl/' \
	-e 's/^{\\headerr/\\facingp{\\headerr/' \
	-e 's/^{\\footerf/\\titlepg{\\footerf/' \
	-e 's/^{\\footerl/\\facingp{\\footerl/' \
	-e 's/^{\\footerr/\\facingp{\\footerr/' \
	-e 's/\\nobrdr/\\brdrnone/g' $IN > $OUT
